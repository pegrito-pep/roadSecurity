<template>
    <footer class="footer">
        <div class="w-100 clearfix">
            <span class="text-center text-sm-left d-md-inline-block">Copyright © 2021 Mairie de Douala Tous droits réservés.</span>
            <span class="float-none float-sm-right mt-1 mt-sm-0 text-center">Crafted with <i class="fa fa-heart text-danger"></i> by <a href="https://www.flysoft-eng.com/" class="text-dark" target="_blank">Flysoft</a></span>
        </div>
    </footer>
</template>

<script>
export default {
    name: 'Footer'
}
</script>